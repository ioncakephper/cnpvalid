# cnpvalid

A CNP Validator WordPress plugin.

## Shortcut

The plugin creates the `cnpv` shortcut. In your page or post include the shortcut `[cnpv]`. The shortcode generate a text field,  button, and a result area. Users enter a CNP value and click the `Validate` button. The button calls Ajax to validate the value of cnp field. If the value is valid, the result field will show Is Valid, otherwise Not valid.

## Download the plugin

1. Download the .zip file
2. In WordPress, goto plugins, add, and choose the .zip file to upload.
3. Activate the plugin.

